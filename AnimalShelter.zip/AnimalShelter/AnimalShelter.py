from pymongo import MongoClient
from bson.objectid import ObjectId

class AnimalShelter(object):
    """ CRUD operations for Animal collection in MongoDB """

    def __init__(self, username, password):
        # Initializing the MongoClient. This helps to 
        # access the MongoDB databases and collections. 
        self.client = MongoClient('mongodb://%s:%s@localhost:46306' % (username, password))
        self.database = self.client['AAC']

# Method to implement the C in CRUD.
    def create(self, data):
        if data is not None:
            self.database.animals.insert(data)  # data should be dictionary            
        else:
            raise Exception("Nothing to save, because data parameter is empty")
            
# Method to implement the R in CRUD. 
    def read(self, lookup):
        
        error = ""
        
        if lookup is not None:
            data = self.database.animals.find(lookup)  # data should be dictionary   
            #print(data)
            
            #return data
            
        else:
            error = "Nothing to lookup, because data parameter is empty"
            
        return error
    
# Method to implement the U in CRUD. 
    def update(self, searchData, updateData):
        if searchData is not None:
            self.database.animals.update_many(updateData)  # data should be dictionary            
        else:
            return "{}"
            
        return result.raw_result
    
# Method to implement the D in CRUD. 
    def delet(self, deleteData):
        if deleteData is not None:
            data.self.database.animals.delete_many(deleteData)  # data should be dictionary            
        else:
            return "{}"
            
        return result.raw_result
