animals = AnimalShelter("accuser2", "Password")

#Valid document lookup
print(animals.lookup ({
    "age_upon_outcome" : "1 year",
    "animal_id" : "A691043",
    "animal_type" : "Dog",
    "breed" : "Pug/Chihuahua Shorthair",
    "color" : "Tan/Black",
    "date_of_birth" : "2013-07-29",
}));

animals = AnimalShelter("accuser", "Password")

#Valid document update
print(animals.updateData ({
    "age_upon_outcome" : "1 year",
    "animal_id" : "A691043",
    "animal_type" : "Dog",
    "breed" : "Pug/Chihuahua Shorthair",
    "color" : "Tan/Black",
    "date_of_birth" : "2013-07-29",
}));

animals = AnimalShelter("accuser", "Password")

#Valid document delete
print(animals.deleteData ({
    "age_upon_outcome" : "1 year",
    "animal_id" : "A691043",
    "animal_type" : "Dog",
    "breed" : "Pug/Chihuahua Shorthair",
    "color" : "Tan/Black",
    "date_of_birth" : "2013-07-29",
}));

animals = AnimalShelter("accuser", "Password")

#Valid document create
print(animals.insert.data ({
    "age_upon_outcome" : "5 year",
    "animal_id" : "A69121469",
    "animal_type" : "Dog",
    "breed" : "Australian Shepherd",
    "color" : "Black/White",
    "date_of_birth" : "2022-07-26",
}));